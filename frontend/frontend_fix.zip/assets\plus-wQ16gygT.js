import{ab as e}from"./index-7MKWztzO.js";const o=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],a=e("plus",o);export{a as P};
