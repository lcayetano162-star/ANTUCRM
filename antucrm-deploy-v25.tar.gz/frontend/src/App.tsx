import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from '@/store/authStore'
import { Toaster } from '@/components/ui/toaster'

// Pages
import Login from '@/pages/Login'
import Dashboard from '@/pages/Dashboard'
import Clients from '@/pages/Clients'
import Opportunities from '@/pages/Opportunities'
import Quotes from '@/pages/Quotes'
import Tasks from '@/pages/Tasks'
import SuperAdminDashboard from '@/pages/super-admin/SuperAdminDashboard'
import SuperAdminPlans from '@/pages/super-admin/SuperAdminPlans'
import SuperAdminTenants from '@/pages/super-admin/SuperAdminTenants'
import SuperAdminAdmins from '@/pages/super-admin/SuperAdminAdmins'
import Layout from '@/components/Layout'
import SuperAdminLayout from '@/components/SuperAdminLayout'

// Protected Route Component
function ProtectedRoute({ children, requireSuperAdmin = false }: { children: React.ReactNode, requireSuperAdmin?: boolean }) {
  const { isAuthenticated, isSuperAdmin } = useAuthStore()
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }
  
  if (requireSuperAdmin && !isSuperAdmin) {
    return <Navigate to="/dashboard" replace />
  }
  
  return <>{children}</>
}

function App() {
  return (
    <>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />
        
        {/* Protected Tenant Routes */}
        <Route path="/" element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="clients" element={<Clients />} />
          <Route path="opportunities" element={<Opportunities />} />
          <Route path="quotes" element={<Quotes />} />
          <Route path="tasks" element={<Tasks />} />
        </Route>
        
        {/* Super Admin Routes */}
        <Route path="/super-admin" element={
          <ProtectedRoute requireSuperAdmin>
            <SuperAdminLayout />
          </ProtectedRoute>
        }>
          <Route index element={<Navigate to="/super-admin/dashboard" replace />} />
          <Route path="dashboard" element={<SuperAdminDashboard />} />
          <Route path="plans" element={<SuperAdminPlans />} />
          <Route path="tenants" element={<SuperAdminTenants />} />
          <Route path="admins" element={<SuperAdminAdmins />} />
        </Route>
        
        {/* Catch all */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
      <Toaster />
    </>
  )
}

export default App
