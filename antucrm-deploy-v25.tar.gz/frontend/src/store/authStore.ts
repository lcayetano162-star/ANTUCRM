import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface User {
  id: string
  email: string
  firstName: string
  lastName: string
  role: string
  tenantId?: string
  isLandlord?: boolean
}

interface AuthState {
  token: string | null
  user: User | null
  isAuthenticated: boolean
  isSuperAdmin: boolean
  
  // Actions
  setAuth: (token: string, user: User) => void
  clearAuth: () => void
  updateUser: (user: Partial<User>) => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      token: null,
      user: null,
      isAuthenticated: false,
      isSuperAdmin: false,

      setAuth: (token, user) => set({
        token,
        user,
        isAuthenticated: true,
        isSuperAdmin: user.role === 'superadmin'
      }),

      clearAuth: () => set({
        token: null,
        user: null,
        isAuthenticated: false,
        isSuperAdmin: false
      }),

      updateUser: (userData) => set((state) => ({
        user: state.user ? { ...state.user, ...userData } : null
      }))
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ 
        token: state.token, 
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        isSuperAdmin: state.isSuperAdmin
      })
    }
  )
)
