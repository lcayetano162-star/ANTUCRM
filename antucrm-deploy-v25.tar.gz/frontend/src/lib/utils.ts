import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: string | Date): string {
  if (!date) return ''
  const d = new Date(date)
  return d.toLocaleDateString('es-DO', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  })
}

export function formatCurrency(amount: number, currency = 'DOP'): string {
  if (amount === null || amount === undefined) return '-'
  return new Intl.NumberFormat('es-DO', {
    style: 'currency',
    currency: currency
  }).format(amount)
}

export function formatNumber(num: number): string {
  if (num === null || num === undefined) return '0'
  return new Intl.NumberFormat('es-DO').format(num)
}
