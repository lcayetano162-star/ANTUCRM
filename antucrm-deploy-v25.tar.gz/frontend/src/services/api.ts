import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios'
import { useAuthStore } from '@/store/authStore'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api'

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
})

// Request interceptor to add auth token
api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = useAuthStore.getState().token
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      useAuthStore.getState().clearAuth()
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// Auth API
export const authApi = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
  
  getMe: () =>
    api.get('/auth/me'),
  
  changePassword: (currentPassword: string, newPassword: string) =>
    api.post('/auth/change-password', { currentPassword, newPassword }),
  
  resetPassword: (userId: string, newPassword: string, isLandlordUser: boolean) =>
    api.post('/auth/reset-password', { userId, newPassword, isLandlordUser })
}

// Users API
export const usersApi = {
  getAll: (tenantId?: string) =>
    api.get('/users', { params: { tenantId } }),
  
  getById: (id: string) =>
    api.get(`/users/${id}`),
  
  create: (data: any) =>
    api.post('/users', data),
  
  update: (id: string, data: any) =>
    api.put(`/users/${id}`, data),
  
  delete: (id: string) =>
    api.delete(`/users/${id}`)
}

// Clients API
export const clientsApi = {
  getAll: (params?: any) =>
    api.get('/clients', { params }),
  
  getById: (id: string) =>
    api.get(`/clients/${id}`),
  
  create: (data: any) =>
    api.post('/clients', data),
  
  update: (id: string, data: any) =>
    api.put(`/clients/${id}`, data),
  
  delete: (id: string) =>
    api.delete(`/clients/${id}`),
  
  convert: (id: string, data: any) =>
    api.post(`/clients/${id}/convert`, data)
}

// Opportunities API
export const opportunitiesApi = {
  getAll: (params?: any) =>
    api.get('/opportunities', { params }),
  
  getPipelineSummary: () =>
    api.get('/opportunities/pipeline/summary'),
  
  getById: (id: string) =>
    api.get(`/opportunities/${id}`),
  
  create: (data: any) =>
    api.post('/opportunities', data),
  
  update: (id: string, data: any) =>
    api.put(`/opportunities/${id}`, data),
  
  delete: (id: string) =>
    api.delete(`/opportunities/${id}`),
  
  move: (id: string, stage: string) =>
    api.post(`/opportunities/${id}/move`, { stage })
}

// Quotes API
export const quotesApi = {
  getAll: (params?: any) =>
    api.get('/quotes', { params }),
  
  getById: (id: string) =>
    api.get(`/quotes/${id}`),
  
  create: (data: any) =>
    api.post('/quotes', data),
  
  updateStatus: (id: string, status: string) =>
    api.put(`/quotes/${id}/status`, { status }),
  
  delete: (id: string) =>
    api.delete(`/quotes/${id}`)
}

// Tasks API
export const tasksApi = {
  getAll: (params?: any) =>
    api.get('/tasks', { params }),
  
  getStats: () =>
    api.get('/tasks/stats/summary'),
  
  getById: (id: string) =>
    api.get(`/tasks/${id}`),
  
  create: (data: any) =>
    api.post('/tasks', data),
  
  update: (id: string, data: any) =>
    api.put(`/tasks/${id}`, data),
  
  complete: (id: string) =>
    api.post(`/tasks/${id}/complete`),
  
  delete: (id: string) =>
    api.delete(`/tasks/${id}`)
}

// Super Admin API
export const superAdminApi = {
  // Dashboard
  getDashboard: () =>
    api.get('/super-admin/dashboard'),
  
  // Plans
  getPlans: () =>
    api.get('/super-admin/plans'),
  
  getPlanById: (id: string) =>
    api.get(`/super-admin/plans/${id}`),
  
  createPlan: (data: any) =>
    api.post('/super-admin/plans', data),
  
  updatePlan: (id: string, data: any) =>
    api.put(`/super-admin/plans/${id}`, data),
  
  deletePlan: (id: string) =>
    api.delete(`/super-admin/plans/${id}`),
  
  // Tenants
  getTenants: () =>
    api.get('/super-admin/tenants'),
  
  getTenantById: (id: string) =>
    api.get(`/super-admin/tenants/${id}`),
  
  createTenant: (data: any) =>
    api.post('/super-admin/tenants', data),
  
  updateTenant: (id: string, data: any) =>
    api.put(`/super-admin/tenants/${id}`, data),
  
  deleteTenant: (id: string) =>
    api.delete(`/super-admin/tenants/${id}`),
  
  suspendTenant: (id: string) =>
    api.post(`/super-admin/tenants/${id}/suspend`),
  
  activateTenant: (id: string) =>
    api.post(`/super-admin/tenants/${id}/activate`),
  
  // Admins
  getAdmins: () =>
    api.get('/super-admin/admins'),
  
  getAdminById: (id: string) =>
    api.get(`/super-admin/admins/${id}`),
  
  createAdmin: (data: any) =>
    api.post('/super-admin/admins', data),
  
  updateAdmin: (id: string, data: any) =>
    api.put(`/super-admin/admins/${id}`, data),
  
  deleteAdmin: (id: string) =>
    api.delete(`/super-admin/admins/${id}`),
  
  resetAdminPassword: (id: string, newPassword: string) =>
    api.post(`/super-admin/admins/${id}/reset-password`, { newPassword }),
  
  toggleAdminStatus: (id: string) =>
    api.post(`/super-admin/admins/${id}/toggle-status`)
}

export default api
