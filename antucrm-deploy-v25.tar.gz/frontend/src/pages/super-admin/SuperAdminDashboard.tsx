import { useEffect, useState } from 'react'
import { 
  Building2, 
  Package, 
  Users, 
  TrendingUp,
  Activity
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { superAdminApi } from '@/services/api'
import { useToast } from '@/hooks/use-toast'
import { formatNumber } from '@/lib/utils'

interface DashboardStats {
  totalTenants: number
  activeTenants: number
  totalPlans: number
  totalAdmins: number
}

interface RecentTenant {
  id: string
  name: string
  slug: string
  status: string
  plan_name: string
  created_at: string
}

export default function SuperAdminDashboard() {
  const { toast } = useToast()
  const [stats, setStats] = useState<DashboardStats>({
    totalTenants: 0,
    activeTenants: 0,
    totalPlans: 0,
    totalAdmins: 0
  })
  const [recentTenants, setRecentTenants] = useState<RecentTenant[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    try {
      setIsLoading(true)
      const response = await superAdminApi.getDashboard()
      
      setStats(response.data.stats)
      setRecentTenants(response.data.recentTenants || [])
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.response?.data?.error || 'No se pudieron cargar las estadísticas',
        variant: 'destructive'
      })
    } finally {
      setIsLoading(false)
    }
  }

  const statCards = [
    {
      title: 'Total Empresas',
      value: formatNumber(stats.totalTenants),
      subtitle: `${formatNumber(stats.activeTenants)} activas`,
      icon: Building2,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Planes de Suscripción',
      value: formatNumber(stats.totalPlans),
      subtitle: 'Disponibles',
      icon: Package,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Super Admins',
      value: formatNumber(stats.totalAdmins),
      subtitle: 'Administradores',
      icon: Users,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    }
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="success">Activo</Badge>
      case 'suspended':
        return <Badge variant="destructive">Suspendido</Badge>
      case 'trial':
        return <Badge variant="warning">Trial</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard Super Admin</h1>
        <p className="text-gray-500">Panel de control del sistema multi-tenant</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {statCards.map((card) => (
          <Card key={card.title}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">{card.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{card.value}</p>
                  <p className="text-sm text-gray-500 mt-1">{card.subtitle}</p>
                </div>
                <div className={`w-12 h-12 ${card.bgColor} rounded-lg flex items-center justify-center`}>
                  <card.icon className={`w-6 h-6 ${card.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Tenants */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">Empresas Recientes</CardTitle>
          <a 
            href="/super-admin/tenants" 
            className="text-sm text-purple-600 hover:text-purple-700"
          >
            Ver todas
          </a>
        </CardHeader>
        <CardContent>
          {recentTenants.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Building2 className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>No hay empresas registradas</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-medium text-gray-500">Nombre</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-500">Slug</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-500">Plan</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-500">Estado</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-500">Creado</th>
                  </tr>
                </thead>
                <tbody>
                  {recentTenants.map((tenant) => (
                    <tr key={tenant.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4 font-medium">{tenant.name}</td>
                      <td className="py-3 px-4 text-gray-500">{tenant.slug}</td>
                      <td className="py-3 px-4">
                        <Badge variant="outline">{tenant.plan_name || 'Sin plan'}</Badge>
                      </td>
                      <td className="py-3 px-4">{getStatusBadge(tenant.status)}</td>
                      <td className="py-3 px-4 text-gray-500">
                        {new Date(tenant.created_at).toLocaleDateString('es-DO')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <a 
          href="/super-admin/plans/new" 
          className="flex items-center gap-4 p-4 bg-white rounded-lg border hover:shadow-md transition-shadow"
        >
          <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
            <Package className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <p className="font-medium text-gray-900">Nuevo Plan</p>
            <p className="text-sm text-gray-500">Crear plan de suscripción</p>
          </div>
        </a>

        <a 
          href="/super-admin/tenants/new" 
          className="flex items-center gap-4 p-4 bg-white rounded-lg border hover:shadow-md transition-shadow"
        >
          <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
            <Building2 className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <p className="font-medium text-gray-900">Nueva Empresa</p>
            <p className="text-sm text-gray-500">Registrar nuevo tenant</p>
          </div>
        </a>

        <a 
          href="/super-admin/admins/new" 
          className="flex items-center gap-4 p-4 bg-white rounded-lg border hover:shadow-md transition-shadow"
        >
          <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
            <Users className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <p className="font-medium text-gray-900">Crear Super Admin</p>
            <p className="text-sm text-gray-500">Nuevo administrador</p>
          </div>
        </a>
      </div>
    </div>
  )
}
