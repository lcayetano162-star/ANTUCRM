import { useEffect, useState } from 'react'
import { Plus, Search, MoreHorizontal, ArrowRight, TrendingUp } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { opportunitiesApi } from '@/services/api'
import { useToast } from '@/hooks/use-toast'
import { formatCurrency } from '@/lib/utils'

interface Opportunity {
  id: string
  name: string
  client_name: string
  stage: string
  probability: number
  estimated_revenue: number
  expected_close_date: string
  owner_first_name: string
  owner_last_name: string
}

const PIPELINE_STAGES = [
  { id: 'qualify', name: 'Calificación', probability: 10 },
  { id: 'analysis', name: 'Análisis', probability: 25 },
  { id: 'proposal', name: 'Propuesta', probability: 50 },
  { id: 'negotiation', name: 'Negociación', probability: 75 },
  { id: 'closed_won', name: 'Cerrada Ganada', probability: 100 },
  { id: 'closed_lost', name: 'Cerrada Perdida', probability: 0 }
]

export default function Opportunities() {
  const { toast } = useToast()
  const [opportunities, setOpportunities] = useState<Opportunity[]>([])
  const [pipelineSummary, setPipelineSummary] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [stageFilter, setStageFilter] = useState('all')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    client_id: '',
    stage: 'qualify',
    estimated_revenue: '',
    expected_close_date: ''
  })

  useEffect(() => {
    loadData()
  }, [stageFilter])

  const loadData = async () => {
    try {
      setIsLoading(true)
      const [oppRes, summaryRes] = await Promise.all([
        opportunitiesApi.getAll(stageFilter !== 'all' ? { stage: stageFilter } : undefined),
        opportunitiesApi.getPipelineSummary()
      ])
      setOpportunities(oppRes.data.opportunities || [])
      setPipelineSummary(summaryRes.data)
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.response?.data?.error || 'No se pudieron cargar las oportunidades',
        variant: 'destructive'
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      await opportunitiesApi.create({
        ...formData,
        estimated_revenue: parseFloat(formData.estimated_revenue)
      })
      toast({
        title: 'Éxito',
        description: 'Oportunidad creada correctamente',
        variant: 'success'
      })
      setIsDialogOpen(false)
      loadData()
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.response?.data?.error || 'No se pudo crear la oportunidad',
        variant: 'destructive'
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleMoveStage = async (opp: Opportunity, newStage: string) => {
    try {
      await opportunitiesApi.move(opp.id, newStage)
      toast({
        title: 'Éxito',
        description: 'Oportunidad movida correctamente',
        variant: 'success'
      })
      loadData()
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.response?.data?.error || 'No se pudo mover la oportunidad',
        variant: 'destructive'
      })
    }
  }

  const getStageBadge = (stage: string) => {
    const colors: Record<string, string> = {
      qualify: 'bg-gray-100 text-gray-800',
      analysis: 'bg-blue-100 text-blue-800',
      proposal: 'bg-yellow-100 text-yellow-800',
      negotiation: 'bg-orange-100 text-orange-800',
      closed_won: 'bg-green-100 text-green-800',
      closed_lost: 'bg-red-100 text-red-800'
    }
    const stageInfo = PIPELINE_STAGES.find(s => s.id === stage)
    return (
      <Badge className={colors[stage] || ''}>
        {stageInfo?.name || stage}
      </Badge>
    )
  }

  const filteredOpportunities = opportunities.filter(opp =>
    opp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    opp.client_name?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Oportunidades</h1>
          <p className="text-gray-500">Gestiona tu pipeline de ventas</p>
        </div>
        <Button onClick={() => setIsDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nueva Oportunidad
        </Button>
      </div>

      {/* Pipeline Stats */}
      {pipelineSummary && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-gray-500">Pipeline</p>
              <p className="text-xl font-bold">{formatCurrency(pipelineSummary.totals?.pipeline_value || 0)}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-gray-500">Ventas Ganadas</p>
              <p className="text-xl font-bold text-green-600">{formatCurrency(pipelineSummary.totals?.won_value || 0)}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-gray-500">Total Oportunidades</p>
              <p className="text-xl font-bold">{pipelineSummary.totals?.total_count || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-gray-500">Tasa de Conversión</p>
              <p className="text-xl font-bold text-cyan-600">
                {pipelineSummary.totals?.total_count > 0
                  ? Math.round((pipelineSummary.stages?.find((s: any) => s.stage === 'closed_won')?.count || 0) / pipelineSummary.totals.total_count * 100)
                  : 0}%
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Buscar oportunidades..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={stageFilter} onValueChange={setStageFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filtrar por etapa" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas las etapas</SelectItem>
            {PIPELINE_STAGES.map(stage => (
              <SelectItem key={stage.id} value={stage.id}>{stage.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Opportunities Table */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin w-8 h-8 border-4 border-cyan-600 border-t-transparent rounded-full mx-auto"></div>
            </div>
          ) : filteredOpportunities.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No hay oportunidades registradas</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-gray-50">
                    <th className="text-left py-3 px-4 font-medium text-gray-500">Oportunidad</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-500">Cliente</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-500">Etapa</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-500">Valor</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-500">Cierre Est.</th>
                    <th className="text-right py-3 px-4 font-medium text-gray-500">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOpportunities.map((opp) => (
                    <tr key={opp.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <div>
                          <p className="font-medium">{opp.name}</p>
                          <p className="text-sm text-gray-500">
                            {opp.owner_first_name} {opp.owner_last_name}
                          </p>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-gray-500">{opp.client_name || '-'}</td>
                      <td className="py-3 px-4">{getStageBadge(opp.stage)}</td>
                      <td className="py-3 px-4">
                        <div>
                          <p className="font-medium">{formatCurrency(opp.estimated_revenue)}</p>
                          <p className="text-sm text-gray-500">{opp.probability}% prob.</p>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-gray-500">
                        {opp.expected_close_date
                          ? new Date(opp.expected_close_date).toLocaleDateString('es-DO')
                          : '-'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              Mover a
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {PIPELINE_STAGES.filter(s => s.id !== opp.stage).map(stage => (
                              <DropdownMenuItem
                                key={stage.id}
                                onClick={() => handleMoveStage(opp, stage.id)}
                              >
                                <ArrowRight className="w-4 h-4 mr-2" />
                                {stage.name}
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Nueva Oportunidad</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nombre *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                placeholder="Ej: Implementación CRM"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="estimated_revenue">Valor Estimado</Label>
                <Input
                  id="estimated_revenue"
                  type="number"
                  value={formData.estimated_revenue}
                  onChange={(e) => setFormData({ ...formData, estimated_revenue: e.target.value })}
                  placeholder="0.00"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="expected_close_date">Fecha de Cierre</Label>
                <Input
                  id="expected_close_date"
                  type="date"
                  value={formData.expected_close_date}
                  onChange={(e) => setFormData({ ...formData, expected_close_date: e.target.value })}
                />
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'Guardando...' : 'Crear Oportunidad'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
