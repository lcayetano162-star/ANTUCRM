import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Eye, EyeOff, Lock, Mail, ArrowRight, Shield, Crown, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useAuthStore } from '@/store/authStore'
import { authApi } from '@/services/api'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'

export default function Login() {
  const navigate = useNavigate()
  const { toast } = useToast()
  const { setAuth } = useAuthStore()
  
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isSuperAdminMode, setIsSuperAdminMode] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await authApi.login(email, password)
      const { token, user } = response.data

      setAuth(token, user)
      
      toast({
        title: '¡Bienvenido!',
        description: `Hola ${user.firstName}, has iniciado sesión exitosamente.`,
        variant: 'success'
      })

      // Redirect based on role
      if (user.role === 'superadmin') {
        navigate('/super-admin/dashboard')
      } else {
        navigate('/dashboard')
      }
    } catch (error: any) {
      toast({
        title: 'Error de inicio de sesión',
        description: error.response?.data?.error || 'Credenciales inválidas',
        variant: 'destructive'
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex">
      {/* Left side - Login Form */}
      <div className="flex-1 flex flex-col justify-center items-center px-8 sm:px-12 lg:px-16 bg-white">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="mb-8 flex justify-center">
            <div className="text-center">
              <h1 className="text-5xl font-bold text-cyan-600">Antü</h1>
              <p className="text-gray-500 mt-2">Customer Relationship Management</p>
            </div>
          </div>

          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Bienvenido de vuelta</CardTitle>
              <CardDescription>
                Ingresa tus credenciales para acceder al CRM
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Email field */}
                <div className="space-y-2">
                  <Label htmlFor="email">Correo electrónico</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="usuario@antucrm.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-11"
                      required
                    />
                  </div>
                </div>

                {/* Password field */}
                <div className="space-y-2">
                  <Label htmlFor="password">Contraseña</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-11 pr-11"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Super Admin Mode Toggle */}
                <div className="flex items-center justify-center pt-2">
                  <button
                    type="button"
                    onClick={() => setIsSuperAdminMode(!isSuperAdminMode)}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                      isSuperAdminMode
                        ? "bg-purple-100 text-purple-700 hover:bg-purple-200"
                        : "text-gray-500 hover:text-gray-700 hover:bg-gray-100"
                    )}
                  >
                    {isSuperAdminMode ? (
                      <>
                        <Crown className="w-4 h-4" />
                        Modo Super Admin Activado
                      </>
                    ) : (
                      <>
                        <Shield className="w-4 h-4" />
                        Acceso Super Admin
                      </>
                    )}
                  </button>
                </div>

                {/* Submit button */}
                <Button
                  type="submit"
                  className={cn(
                    "w-full h-11 text-base font-semibold gap-2",
                    isSuperAdminMode
                      ? "bg-gradient-to-r from-purple-600 to-indigo-700 hover:from-purple-700 hover:to-indigo-800"
                      : "bg-gradient-to-r from-cyan-600 to-cyan-700 hover:from-cyan-700 hover:to-cyan-800"
                  )}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      {isSuperAdminMode ? (
                        <>
                          <Crown className="w-5 h-5" />
                          Acceder como Super Admin
                        </>
                      ) : (
                        <>
                          Iniciar sesión
                          <ArrowRight className="w-5 h-5" />
                        </>
                      )}
                    </>
                  )}
                </Button>
              </form>

              {/* Demo credentials */}
              <div className="mt-6 p-4 bg-gray-50 rounded-lg text-sm">
                <p className="font-medium text-gray-700 mb-2">Credenciales de demo:</p>
                <div className="space-y-1 text-gray-600">
                  <p><span className="font-medium">Super Admin:</span> lcayetano162@gmail.com / AntuCRM2024!</p>
                  <p><span className="font-medium">Admin:</span> admin@antucrm.com / admin123</p>
                  <p><span className="font-medium">Vendedor:</span> vendedor@antucrm.com / vendedor123</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Footer */}
          <p className="mt-8 text-center text-sm text-gray-500">
            © 2024 Antü CRM - Todos los derechos reservados
          </p>
        </div>
      </div>

      {/* Right side - Decorative */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-cyan-600 via-cyan-700 to-blue-800 relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full translate-x-1/2 translate-y-1/2" />
        </div>

        {/* Content */}
        <div className="relative z-10 flex flex-col justify-center items-center px-16 text-white">
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-4">
              Gestiona tu negocio
            </h2>
            <p className="text-xl text-cyan-100 mb-8 max-w-md">
              El CRM completo para administrar oportunidades, clientes y ventas en un solo lugar.
            </p>

            {/* Features */}
            <div className="space-y-4 text-left">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <div>
                  <p className="font-semibold">Pipeline de Ventas</p>
                  <p className="text-sm text-cyan-200">Seguimiento de oportunidades</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <div>
                  <p className="font-semibold">Gestión de Clientes</p>
                  <p className="text-sm text-cyan-200">Base de datos completa</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                </div>
                <div>
                  <p className="font-semibold">Tareas y Actividades</p>
                  <p className="text-sm text-cyan-200">Organiza tu día a día</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
