import { useEffect, useState } from 'react'
import { 
  Users, 
  Briefcase, 
  FileText, 
  CheckSquare,
  TrendingUp,
  DollarSign
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { opportunitiesApi, tasksApi } from '@/services/api'
import { useToast } from '@/hooks/use-toast'
import { formatCurrency, formatNumber } from '@/lib/utils'

interface DashboardStats {
  opportunities: {
    total: number
    pipeline_value: number
    won_value: number
  }
  tasks: {
    pending: number
    overdue: number
  }
}

export default function Dashboard() {
  const { toast } = useToast()
  const [stats, setStats] = useState<DashboardStats>({
    opportunities: { total: 0, pipeline_value: 0, won_value: 0 },
    tasks: { pending: 0, overdue: 0 }
  })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadStats()
  }, [])

  const loadStats = async () => {
    try {
      setIsLoading(true)
      
      const [pipelineRes, tasksRes] = await Promise.all([
        opportunitiesApi.getPipelineSummary(),
        tasksApi.getStats()
      ])

      setStats({
        opportunities: {
          total: pipelineRes.data.totals?.total_count || 0,
          pipeline_value: pipelineRes.data.totals?.pipeline_value || 0,
          won_value: pipelineRes.data.totals?.won_value || 0
        },
        tasks: {
          pending: tasksRes.data.stats?.my_pending || 0,
          overdue: tasksRes.data.stats?.overdue || 0
        }
      })
    } catch (error) {
      toast({
        title: 'Error',
        description: 'No se pudieron cargar las estadísticas',
        variant: 'destructive'
      })
    } finally {
      setIsLoading(false)
    }
  }

  const statCards = [
    {
      title: 'Oportunidades',
      value: formatNumber(stats.opportunities.total),
      subtitle: `${formatCurrency(stats.opportunities.pipeline_value)} en pipeline`,
      icon: Briefcase,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Ventas Ganadas',
      value: formatCurrency(stats.opportunities.won_value),
      subtitle: 'Total acumulado',
      icon: DollarSign,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Tareas Pendientes',
      value: formatNumber(stats.tasks.pending),
      subtitle: stats.tasks.overdue > 0 ? `${stats.tasks.overdue} vencidas` : 'Al día',
      icon: CheckSquare,
      color: stats.tasks.overdue > 0 ? 'text-red-600' : 'text-yellow-600',
      bgColor: stats.tasks.overdue > 0 ? 'bg-red-50' : 'bg-yellow-50'
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500">Resumen de tu actividad</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map((card) => (
          <Card key={card.title}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">{card.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{card.value}</p>
                  <p className="text-sm text-gray-500 mt-1">{card.subtitle}</p>
                </div>
                <div className={`w-12 h-12 ${card.bgColor} rounded-lg flex items-center justify-center`}>
                  <card.icon className={`w-6 h-6 ${card.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Acciones Rápidas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <a 
                href="/clients/new" 
                className="flex items-center gap-3 p-4 rounded-lg border hover:bg-gray-50 transition-colors"
              >
                <div className="w-10 h-10 bg-cyan-50 rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-cyan-600" />
                </div>
                <div>
                  <p className="font-medium">Nuevo Cliente</p>
                  <p className="text-sm text-gray-500">Agregar prospecto</p>
                </div>
              </a>
              
              <a 
                href="/opportunities/new" 
                className="flex items-center gap-3 p-4 rounded-lg border hover:bg-gray-50 transition-colors"
              >
                <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
                  <Briefcase className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium">Nueva Oportunidad</p>
                  <p className="text-sm text-gray-500">Crear negocio</p>
                </div>
              </a>
              
              <a 
                href="/quotes/new" 
                className="flex items-center gap-3 p-4 rounded-lg border hover:bg-gray-50 transition-colors"
              >
                <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center">
                  <FileText className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="font-medium">Nueva Cotización</p>
                  <p className="text-sm text-gray-500">Generar presupuesto</p>
                </div>
              </a>
              
              <a 
                href="/tasks/new" 
                className="flex items-center gap-3 p-4 rounded-lg border hover:bg-gray-50 transition-colors"
              >
                <div className="w-10 h-10 bg-yellow-50 rounded-lg flex items-center justify-center">
                  <CheckSquare className="w-5 h-5 text-yellow-600" />
                </div>
                <div>
                  <p className="font-medium">Nueva Tarea</p>
                  <p className="text-sm text-gray-500">Asignar actividad</p>
                </div>
              </a>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Pipeline de Ventas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Calificación</span>
                <Badge variant="secondary">10%</Badge>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-gray-400 h-2 rounded-full" style={{ width: '10%' }}></div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Análisis</span>
                <Badge variant="secondary">25%</Badge>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-400 h-2 rounded-full" style={{ width: '25%' }}></div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Propuesta</span>
                <Badge variant="secondary">50%</Badge>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-yellow-400 h-2 rounded-full" style={{ width: '50%' }}></div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Negociación</span>
                <Badge variant="secondary">75%</Badge>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-orange-400 h-2 rounded-full" style={{ width: '75%' }}></div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Cerrada Ganada</span>
                <Badge variant="success">100%</Badge>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: '100%' }}></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
