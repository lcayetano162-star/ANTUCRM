const { query, testConnection } = require('./database');

const migrations = [
  // ============================================
  // LANDLORD TABLES (Multi-Tenant SaaS)
  // ============================================
  
  // Enable UUID extension
  `CREATE EXTENSION IF NOT EXISTS "uuid-ossp";`,
  
  // Plans table for subscription packages
  `CREATE TABLE IF NOT EXISTS plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    price_monthly DECIMAL(10, 2) NOT NULL DEFAULT 0,
    price_yearly DECIMAL(10, 2) NOT NULL DEFAULT 0,
    currency VARCHAR(3) DEFAULT 'USD',
    features JSONB DEFAULT '[]',
    limits JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,
  
  // Tenants table for companies/instances
  `CREATE TABLE IF NOT EXISTS tenants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    domain VARCHAR(255),
    plan_id UUID REFERENCES plans(id),
    database_name VARCHAR(100),
    status VARCHAR(20) DEFAULT 'active',
    settings JSONB DEFAULT '{}',
    billing_info JSONB DEFAULT '{}',
    trial_ends_at TIMESTAMP,
    subscribed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,
  
  // Landlord users (Super Admins)
  `CREATE TABLE IF NOT EXISTS landlord_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    role VARCHAR(20) DEFAULT 'superadmin',
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,
  
  // Tenant-Users link table
  `CREATE TABLE IF NOT EXISTS tenant_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID NOT NULL,
    role VARCHAR(50) DEFAULT 'member',
    is_owner BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,

  // ============================================
  // TENANT TABLES (Per-company data)
  // ============================================
  
  // Users table (tenant-specific)
  `CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    role VARCHAR(20) DEFAULT 'seller',
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP,
    password_changed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, email)
  );`,
  
  // Contacts table (for clients/prospects)
  `CREATE TABLE IF NOT EXISTS contacts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100),
    email VARCHAR(255),
    phone VARCHAR(50),
    mobile VARCHAR(50),
    position VARCHAR(100),
    department VARCHAR(100),
    is_primary BOOLEAN DEFAULT false,
    client_id UUID,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,
  
  // Clients table
  `CREATE TABLE IF NOT EXISTS clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    rnc VARCHAR(50),
    phone VARCHAR(50),
    email VARCHAR(255),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(100) DEFAULT 'República Dominicana',
    status VARCHAR(20) DEFAULT 'prospect',
    source VARCHAR(100),
    notes TEXT,
    assigned_to UUID REFERENCES users(id),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,
  
  // Opportunities table
  `CREATE TABLE IF NOT EXISTS opportunities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    client_id UUID REFERENCES clients(id),
    contact_id UUID REFERENCES contacts(id),
    owner_id UUID REFERENCES users(id),
    stage VARCHAR(20) DEFAULT 'qualify',
    probability INTEGER DEFAULT 0,
    estimated_revenue DECIMAL(15, 2) DEFAULT 0,
    expected_close_date DATE,
    actual_close_date DATE,
    source VARCHAR(100),
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,
  
  // Quotes table
  `CREATE TABLE IF NOT EXISTS quotes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    quote_number VARCHAR(50) UNIQUE NOT NULL,
    client_id UUID REFERENCES clients(id),
    opportunity_id UUID REFERENCES opportunities(id),
    status VARCHAR(20) DEFAULT 'draft',
    subtotal DECIMAL(15, 2) DEFAULT 0,
    tax_rate DECIMAL(5, 2) DEFAULT 0,
    tax_amount DECIMAL(15, 2) DEFAULT 0,
    total_monthly DECIMAL(15, 2) DEFAULT 0,
    total_onetime DECIMAL(15, 2) DEFAULT 0,
    valid_until DATE,
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,
  
  // Quote items table
  `CREATE TABLE IF NOT EXISTS quote_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quote_id UUID REFERENCES quotes(id) ON DELETE CASCADE,
    product_name VARCHAR(255) NOT NULL,
    description TEXT,
    quantity INTEGER DEFAULT 1,
    unit_price DECIMAL(15, 2) DEFAULT 0,
    discount_percent DECIMAL(5, 2) DEFAULT 0,
    total_price DECIMAL(15, 2) DEFAULT 0,
    is_recurring BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,
  
  // Tasks table
  `CREATE TABLE IF NOT EXISTS tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    assigned_to UUID REFERENCES users(id),
    related_to_type VARCHAR(50),
    related_to_id UUID,
    status VARCHAR(20) DEFAULT 'pending',
    priority VARCHAR(20) DEFAULT 'medium',
    due_date TIMESTAMP,
    completed_at TIMESTAMP,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,
  
  // Activities/Notes table
  `CREATE TABLE IF NOT EXISTS activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL,
    subject VARCHAR(255),
    description TEXT,
    related_to_type VARCHAR(50),
    related_to_id UUID,
    performed_by UUID REFERENCES users(id),
    performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );`,

  // ============================================
  // INDEXES
  // ============================================
  `CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);`,
  `CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);`,
  `CREATE INDEX IF NOT EXISTS idx_users_last_login ON users(last_login);`,
  `CREATE INDEX IF NOT EXISTS idx_contacts_tenant ON contacts(tenant_id);`,
  `CREATE INDEX IF NOT EXISTS idx_contacts_client ON contacts(client_id);`,
  `CREATE INDEX IF NOT EXISTS idx_clients_tenant ON clients(tenant_id);`,
  `CREATE INDEX IF NOT EXISTS idx_clients_status ON clients(status);`,
  `CREATE INDEX IF NOT EXISTS idx_clients_assigned ON clients(assigned_to);`,
  `CREATE INDEX IF NOT EXISTS idx_opportunities_tenant ON opportunities(tenant_id);`,
  `CREATE INDEX IF NOT EXISTS idx_opportunities_stage ON opportunities(stage);`,
  `CREATE INDEX IF NOT EXISTS idx_opportunities_owner ON opportunities(owner_id);`,
  `CREATE INDEX IF NOT EXISTS idx_quotes_tenant ON quotes(tenant_id);`,
  `CREATE INDEX IF NOT EXISTS idx_tasks_tenant ON tasks(tenant_id);`,
  `CREATE INDEX IF NOT EXISTS idx_tasks_assigned ON tasks(assigned_to);`,
  `CREATE INDEX IF NOT EXISTS idx_activities_tenant ON activities(tenant_id);`,
  `CREATE INDEX IF NOT EXISTS idx_tenant_users_tenant ON tenant_users(tenant_id);`,
  `CREATE INDEX IF NOT EXISTS idx_tenants_slug ON tenants(slug);`,
  `CREATE INDEX IF NOT EXISTS idx_tenants_plan ON tenants(plan_id);`,
];

const seedData = async () => {
  try {
    // Check if plans exist
    const plansResult = await query('SELECT COUNT(*) as count FROM plans');
    if (parseInt(plansResult.rows[0].count) === 0) {
      console.log('🌱 Insertando planes iniciales...');
      await query(`
        INSERT INTO plans (name, slug, description, price_monthly, price_yearly, features, limits) VALUES
        ('Básico', 'basico', 'Plan básico para pequeñas empresas', 29, 290, '["Hasta 5 usuarios", "1000 contactos", "Soporte por email"]'::jsonb, '{"users": 5, "contacts": 1000}'::jsonb),
        ('Profesional', 'profesional', 'Plan para empresas en crecimiento', 79, 790, '["Hasta 20 usuarios", "10000 contactos", "Soporte prioritario", "Reportes avanzados"]'::jsonb, '{"users": 20, "contacts": 10000}'::jsonb),
        ('Empresarial', 'empresarial', 'Plan completo para grandes empresas', 199, 1990, '["Usuarios ilimitados", "Contactos ilimitados", "Soporte 24/7", "API access", "Personalización completa"]'::jsonb, '{"users": -1, "contacts": -1}'::jsonb)
      `);
      console.log('✅ Planes insertados');
    }

    // Check if super admin exists
    const adminResult = await query('SELECT COUNT(*) as count FROM landlord_users WHERE email = $1', ['lcayetano162@gmail.com']);
    if (parseInt(adminResult.rows[0].count) === 0) {
      console.log('🌱 Creando Super Admin inicial...');
      const bcrypt = require('bcrypt');
      const passwordHash = await bcrypt.hash('AntuCRM2024!', 10);
      await query(`
        INSERT INTO landlord_users (email, password_hash, first_name, last_name, role, is_active)
        VALUES ($1, $2, 'Super', 'Admin', 'superadmin', true)
      `, ['lcayetano162@gmail.com', passwordHash]);
      console.log('✅ Super Admin creado');
    }
  } catch (error) {
    console.error('❌ Error en seed:', error.message);
  }
};

const runMigrations = async () => {
  console.log('🔄 Verificando conexión a base de datos...');
  console.log(`   Host: ${process.env.DB_HOST || 'localhost'}`);
  console.log(`   Port: ${process.env.DB_PORT || '5432'}`);
  console.log(`   Database: ${process.env.DB_NAME || 'antucrm_production'}`);
  console.log(`   User: ${process.env.DB_USER || 'antucrm_admin'}`);
  
  try {
    await testConnection();
    console.log('✅ Conexión exitosa\n');
  } catch (error) {
    console.error('❌ No se pudo conectar a la base de datos:', error.message);
    console.error('\nVerifique que:');
    console.error('  1. PostgreSQL está ejecutándose');
    console.error('  2. Las credenciales en .env son correctas');
    console.error('  3. El host y puerto son accesibles');
    process.exit(1);
  }

  console.log('🔄 Ejecutando migraciones...\n');
  let successCount = 0;
  let skipCount = 0;
  let errorCount = 0;

  for (let i = 0; i < migrations.length; i++) {
    try {
      await query(migrations[i]);
      successCount++;
    } catch (error) {
      if (error.message.includes('already exists') || 
          error.message.includes('duplicate key') ||
          error.code === '42P07' ||  // PostgreSQL: relation already exists
          error.code === '42710') {  // PostgreSQL: constraint already exists
        skipCount++;
      } else {
        console.error(`❌ Error en migración ${i + 1}:`, error.message);
        errorCount++;
      }
    }
  }

  console.log('\n📊 Resumen de migraciones:');
  console.log(`   ✅ Exitosas: ${successCount}`);
  console.log(`   ⏭️  Ya existían: ${skipCount}`);
  console.log(`   ❌ Errores: ${errorCount}`);

  if (errorCount === 0) {
    console.log('\n✅ Migraciones completadas exitosamente');
    await seedData();
  } else {
    console.log('\n⚠️  Algunas migraciones fallaron');
  }

  process.exit(errorCount > 0 ? 1 : 0);
};

runMigrations();
